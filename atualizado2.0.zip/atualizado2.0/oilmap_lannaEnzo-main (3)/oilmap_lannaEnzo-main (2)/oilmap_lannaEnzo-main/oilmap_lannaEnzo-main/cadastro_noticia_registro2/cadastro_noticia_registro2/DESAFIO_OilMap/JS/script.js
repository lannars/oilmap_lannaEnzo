// Script principal para o OilMap
document.addEventListener('DOMContentLoaded', () => {
    // Elementos do DOM
    const loadingScreen = document.getElementById('loading-screen');
    const loginScreen = document.getElementById('login-screen');
    const progressBar = document.querySelector('.progress');
    const loadingText = document.querySelector('.loading-text');
    const loginForm = document.getElementById('loginForm');
    const emailInput = document.getElementById('email');
    const passwordInput = document.getElementById('password');
    const rememberCheckbox = document.getElementById('remember');
    
    // Configuração de animação de carregamento
    const loadingTexts = [
      'Carregando recursos do sistema...',
      'Inicializando serviços...',
      'Verificando conexão...',
      'Preparando interface...',
      'Quase pronto...'
    ];
    
    // Função para simular carregamento com progresso real
    function simulateLoading() {
      let progress = 0;
      let textIndex = 0;
      
      const interval = setInterval(() => {
        progress += Math.random() * 3;
        
        if (progress >= 100) {
          progress = 100;
          clearInterval(interval);
          
          // Adiciona uma pequena pausa antes de mostrar a tela de login
          setTimeout(() => {
            // Aplicar animação de fade out/in
            loadingScreen.classList.add('fade-out');
            
            setTimeout(() => {
              loadingScreen.style.display = 'none';
              loginScreen.style.display = 'block';
              
              // Adiciona um pequeno atraso antes do fade in
              setTimeout(() => {
                loginScreen.classList.add('fade-in');
                // Foca no campo de email automaticamente
                emailInput.focus();
              }, 50);
            }, 500); // Tempo de duração da animação fade out
          }, 400);
        }
        
        // Atualiza a barra de progresso com animação suave
        progressBar.style.width = `${progress}%`;
        
        // Alterna os textos de carregamento
        if (progress > (textIndex + 1) * 20 && textIndex < loadingTexts.length - 1) {
          textIndex++;
          // Animação de fade para o texto
          loadingText.classList.add('fade-text');
          setTimeout(() => {
            loadingText.textContent = loadingTexts[textIndex];
            loadingText.classList.remove('fade-text');
          }, 300);
        }
      }, 100);
    }
    
    // Inicia a simulação de carregamento
    simulateLoading();
    
    // Animação para as gotas de óleo
    animateOilDrops();
  
    // Verificar se existem credenciais salvas
    checkSavedCredentials();
    
    // Event listeners
    setupEventListeners();
  });
  
  // Animação para as gotas de óleo
  function animateOilDrops() {
    const drops = document.querySelectorAll('.oil-drop');
    
    drops.forEach((drop, index) => {
      // Configurações de animação diferentes para cada gota
      const delay = index * 0.8;
      const duration = 2 + Math.random() * 2;
      
      // Aplicar animação CSS via JavaScript
      drop.style.animation = `float ${duration}s ease-in-out ${delay}s infinite alternate`;
      
      // Posições aleatórias iniciais
      const randomX = Math.floor(Math.random() * 80) + 10; // Entre 10% e 90% da largura
      drop.style.left = `${randomX}%`;
    });
  }
  
  // Gerenciar eventos de interação com o usuário
  function setupEventListeners() {
    const loginForm = document.getElementById('loginForm');
    const emailInput = document.getElementById('email');
    const passwordInput = document.getElementById('password');
    const rememberCheckbox = document.getElementById('remember');
    const togglePasswordBtn = document.querySelector('.toggle-password');
    
    // Validação do formulário de login
    loginForm.addEventListener('submit', (e) => {
      e.preventDefault();
      
      // Validar campos
      if (!validateEmail(emailInput.value)) {
        showError(emailInput, 'Por favor, insira um e-mail válido');
        return;
      }
      
      if (!validatePassword(passwordInput.value)) {
        showError(passwordInput, 'A senha deve ter pelo menos 6 caracteres');
        return;
      }
      
      // Salvar credenciais se a opção "lembrar-me" estiver marcada
      if (rememberCheckbox.checked) {
        saveCredentials(emailInput.value, passwordInput.value);
      } else {
        clearSavedCredentials();
      }
      
      // Simulação de login bem-sucedido
      showLoginSuccess();
    });
    
    // Remover mensagens de erro quando o usuário começa a digitar
    emailInput.addEventListener('input', () => removeError(emailInput));
    passwordInput.addEventListener('input', () => removeError(passwordInput));
    
    // Alternar visibilidade da senha
    togglePasswordBtn.addEventListener('click', togglePassword);
    
    // Efeitos visuais para os campos de formulário
    const formInputs = document.querySelectorAll('input');
    formInputs.forEach(input => {
      // Adicionar classe 'active' quando o campo estiver em foco
      input.addEventListener('focus', () => {
        input.parentElement.classList.add('active');
      });
      
      // Remover classe 'active' quando o campo perder o foco
      input.addEventListener('blur', () => {
        if (!input.value) {
          input.parentElement.classList.remove('active');
        }
      });
    });
  }
  
  // Toggle de visibilidade da senha com animação
  function togglePassword() {
    const passwordInput = document.getElementById('password');
    const toggleIcon = document.querySelector('.toggle-password');
    
    if (passwordInput.type === 'password') {
      passwordInput.type = 'text';
      toggleIcon.textContent = '👁️';
      toggleIcon.classList.add('active');
    } else {
      passwordInput.type = 'password';
      toggleIcon.textContent = '👁️';
      toggleIcon.classList.remove('active');
    }
    
    // Adicionar uma pequena animação
    toggleIcon.classList.add('pulse');
    setTimeout(() => toggleIcon.classList.remove('pulse'), 300);
  }
  
  // Validar formato de e-mail
  function validateEmail(email) {
    const regex = /^[^\s@]+@[^\s@]+\.[^\s@]+$/;
    return regex.test(email);
  }
  
  // Validar senha
  function validatePassword(password) {
    return password.length >= 6;
  }
  
  // Mostrar mensagem de erro
  function showError(input, message) {
    const formGroup = input.parentElement;
    
    // Remover erro anterior se existir
    removeError(input);
    
    // Criar e adicionar mensagem de erro
    const errorMessage = document.createElement('div');
    errorMessage.className = 'error-message';
    errorMessage.textContent = message;
    
    formGroup.classList.add('error');
    formGroup.appendChild(errorMessage);
    
    // Animação de shake no input
    input.classList.add('shake');
    setTimeout(() => input.classList.remove('shake'), 500);
  }
  
  // Remover mensagem de erro
  function removeError(input) {
    const formGroup = input.parentElement;
    const errorMessage = formGroup.querySelector('.error-message');
    
    if (errorMessage) {
      formGroup.removeChild(errorMessage);
      formGroup.classList.remove('error');
    }
  }
  
  // Salvar credenciais no localStorage
  function saveCredentials(email, password) {
    // Aqui você poderia implementar uma criptografia mais segura
    // Para um sistema real, não armazene senhas dessa forma
    localStorage.setItem('oilmap_email', email);
    localStorage.setItem('oilmap_remember', 'true');
    
    // Armazenar apenas um token ou indicador que o usuário está logado
    // não a senha real em produção
    localStorage.setItem('oilmap_auth', btoa(email + ':' + password));
  }
  
  // Limpar credenciais do localStorage
  function clearSavedCredentials() {
    localStorage.removeItem('oilmap_email');
    localStorage.removeItem('oilmap_remember');
    localStorage.removeItem('oilmap_auth');
  }
  
  // Verificar se existem credenciais salvas
  function checkSavedCredentials() {
    const savedEmail = localStorage.getItem('oilmap_email');
    const rememberChecked = localStorage.getItem('oilmap_remember');
    
    if (savedEmail && rememberChecked === 'true') {
      document.getElementById('email').value = savedEmail;
      document.getElementById('remember').checked = true;
      
      // Adicionar classe active para manter o estilo do label
      document.getElementById('email').parentElement.classList.add('active');
    }
  }
  
  // Simular login bem-sucedido
  function showLoginSuccess() {
    const loginButton = document.querySelector('.login-button');
    const originalText = loginButton.textContent;
    
    // Desativar botão e mostrar progresso
    loginButton.disabled = true;
    loginButton.innerHTML = '<span class="spinner"></span> Entrando...';
    
    // Simular requisição de API
    setTimeout(() => {
      loginButton.innerHTML = '<span class="check">✓</span> Sucesso!';
      
      // Redirecionar após o login (substitua pela URL correta)
      setTimeout(() => {
        window.location.href = 'dashboard.html';
        // Alternativa: mostrar um modal/overlay de bem-vindo
        // showWelcomeOverlay();
      }, 1000);
    }, 1500);
  }
  
  // Efeito de fundo para a página (opcional)
  function createBackgroundEffect() {
    const background = document.createElement('div');
    background.className = 'background-effect';
    document.body.appendChild(background);
    
    for (let i = 0; i < 12; i++) {
      const particle = document.createElement('div');
      particle.className = 'particle';
      
      // Posição aleatória
      particle.style.left = `${Math.random() * 100}%`;
      particle.style.top = `${Math.random() * 100}%`;
      
      // Tamanho aleatório
      const size = Math.random() * 30 + 10;
      particle.style.width = `${size}px`;
      particle.style.height = `${size}px`;
      
      // Adicionar ao fundo
      background.appendChild(particle);
      
      // Animar
      animateParticle(particle);
    }
  }
  
  // Animar partículas de fundo
  function animateParticle(particle) {
    // Posição inicial
    let x = parseFloat(particle.style.left);
    let y = parseFloat(particle.style.top);
    
    // Velocidade aleatória
    const speedX = (Math.random() - 0.5) * 0.1;
    const speedY = (Math.random() - 0.5) * 0.1;
    
    function move() {
      // Atualizar posição
      x += speedX;
      y += speedY;
      
      // Verificar limites
      if (x > 100) x = 0;
      if (x < 0) x = 100;
      if (y > 100) y = 0;
      if (y < 0) y = 100;
      
      // Aplicar nova posição
      particle.style.left = `${x}%`;
      particle.style.top = `${y}%`;
      
      // Continuar animação
      requestAnimationFrame(move);
    }
    
    move();
  }
  