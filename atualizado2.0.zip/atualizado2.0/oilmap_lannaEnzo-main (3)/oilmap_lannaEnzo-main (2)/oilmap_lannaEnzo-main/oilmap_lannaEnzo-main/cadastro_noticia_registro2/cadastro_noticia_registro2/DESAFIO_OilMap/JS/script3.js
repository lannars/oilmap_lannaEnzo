/**
 * OilMap News Portal - JavaScript Principal
 * Versão: 1.0.0
 * Desenvolvido para: OilMap
 * Data: Maio de 2025
 */

// Aguarda o carregamento completo do DOM
document.addEventListener('DOMContentLoaded', () => {
    // Inicialização dos componentes principais
    initializeHeader();
    initializeNewsCards();
    initializeAnimations();
    initializeInfiniteScroll();
    initializeNewsFilter();
    initializeSearchFunctionality();
    initializeTimeAgo();
    
    // Sistema de notificação de novas notícias
    setupNewsRefresh();
  });
  
  /**
   * Inicializa animações e comportamentos do cabeçalho
   */
  function initializeHeader() {
    const header = document.querySelector('header');
    const logo = document.querySelector('.logo');
    const profileIcon = document.querySelector('.profile-icon');
    
    // Efeito de scroll para o cabeçalho
    let lastScrollTop = 0;
    
    window.addEventListener('scroll', () => {
      const scrollTop = window.pageYOffset || document.documentElement.scrollTop;
      
      // Adiciona classe 'scrolled' ao cabeçalho quando a página é rolada
      if (scrollTop > 10) {
        header.classList.add('scrolled');
      } else {
        header.classList.remove('scrolled');
      }
      
      // Efeito de esconder/mostrar cabeçalho ao rolar
      if (scrollTop > lastScrollTop && scrollTop > 200) {
        header.style.transform = 'translateY(-100%)';
      } else {
        header.style.transform = 'translateY(0)';
      }
      
      lastScrollTop = scrollTop;
    });
    
    // Animação para o logo
    logo.addEventListener('click', () => {
      logo.classList.add('pulse');
      setTimeout(() => logo.classList.remove('pulse'), 500);
      
      // Rolar para o topo suavemente
      window.scrollTo({
        top: 0,
        behavior: 'smooth'
      });
    });
    
    // Menu de perfil dropdown
    if (profileIcon) {
      profileIcon.addEventListener('click', () => {
        // Verifica se já existe um menu de perfil
        let profileMenu = document.querySelector('.profile-menu');
        
        if (profileMenu) {
          // Se o menu já existe, apenas alterna sua visibilidade
          profileMenu.classList.toggle('active');
        } else {
          // Cria um novo menu de perfil
          profileMenu = document.createElement('div');
          profileMenu.className = 'profile-menu active';
          
          const menuItems = [
            { label: 'Meu Perfil', icon: '👤' },
            { label: 'Notícias Salvas', icon: '📌' },
            { label: 'Configurações', icon: '⚙️' },
            { label: 'Sair', icon: '🚪' }
          ];
          
          menuItems.forEach(item => {
            const menuItem = document.createElement('div');
            menuItem.className = 'menu-item';
            menuItem.innerHTML = `<span class="menu-icon">${item.icon}</span> ${item.label}`;
            
            menuItem.addEventListener('click', () => {
              // Simula ação de clique no item de menu
              console.log(`Clicou em: ${item.label}`);
              
              // Fecha o menu após clicar
              profileMenu.classList.remove('active');
            });
            
            profileMenu.appendChild(menuItem);
          });
          
          // Adiciona o menu ao header
          header.appendChild(profileMenu);
        }
        
        // Fecha o menu ao clicar fora dele
        document.addEventListener('click', (event) => {
          if (!profileMenu.contains(event.target) && event.target !== profileIcon) {
            profileMenu.classList.remove('active');
          }
        });
      });
    }
    
    // Adiciona barra de pesquisa ao header
    const searchIcon = document.createElement('div');
    searchIcon.className = 'search-icon';
    searchIcon.innerHTML = '🔍';
    header.insertBefore(searchIcon, profileIcon);
    
    searchIcon.addEventListener('click', () => {
      const searchBar = document.querySelector('.search-bar') || createSearchBar();
      searchBar.classList.toggle('active');
      
      if (searchBar.classList.contains('active')) {
        searchBar.querySelector('input').focus();
      }
    });
    
    function createSearchBar() {
      const searchBar = document.createElement('div');
      searchBar.className = 'search-bar';
      
      const searchInput = document.createElement('input');
      searchInput.type = 'text';
      searchInput.placeholder = 'Buscar notícias...';
      
      const searchButton = document.createElement('button');
      searchButton.textContent = 'Buscar';
      
      searchBar.appendChild(searchInput);
      searchBar.appendChild(searchButton);
      header.appendChild(searchBar);
      
      return searchBar;
    }
  }
  
  /**
   * Inicializa animações e interações para os cards de notícias
   */
  function initializeNewsCards() {
    const newsCards = document.querySelectorAll('.noticia-card');
    
    newsCards.forEach(card => {
      // Adiciona efeito de hover com elevação
      card.addEventListener('mouseenter', () => {
        card.classList.add('hovered');
      });
      
      card.addEventListener('mouseleave', () => {
        card.classList.remove('hovered');
      });
      
      // Adiciona funcionalidade de clique para abrir a notícia completa
      card.addEventListener('click', () => {
        const title = card.querySelector('h4').textContent;
        const source = card.querySelector('.fonte-nome').textContent;
        
        openNewsDetail(title, source, card);
      });
      
      // Adiciona botão de salvar/favoritar
      const saveButton = document.createElement('div');
      saveButton.className = 'save-button';
      saveButton.innerHTML = '🔖';
      saveButton.title = 'Salvar notícia';
      
      saveButton.addEventListener('click', (e) => {
        e.stopPropagation(); // Evita que o clique se propague para o card
        saveButton.classList.toggle('saved');
        
        if (saveButton.classList.contains('saved')) {
          saveButton.innerHTML = '📌';
          saveButton.title = 'Notícia salva';
          showNotification('Notícia salva com sucesso!');
        } else {
          saveButton.innerHTML = '🔖';
          saveButton.title = 'Salvar notícia';
          showNotification('Notícia removida dos salvos.');
        }
      });
      
      card.appendChild(saveButton);
      
      // Adiciona tempo relativo
      updateRelativeTime(card.querySelector('.tempo'));
    });
  }
  
  /**
   * Abre o detalhe de uma notícia em um modal
   */
  function openNewsDetail(title, source, card) {
    // Cria o overlay do modal
    const overlay = document.createElement('div');
    overlay.className = 'news-overlay';
    
    // Cria o conteúdo do modal
    const modal = document.createElement('div');
    modal.className = 'news-modal';
    
    // Clone a imagem da notícia para o modal
    const imageClone = card.querySelector('.noticia-imagem img').cloneNode(true);
    imageClone.className = 'modal-image';
    
    // Estrutura do modal
    modal.innerHTML = `
      <div class="modal-header">
        <div class="modal-source">
          <div class="fonte-icone"></div>
          <div class="fonte-nome">${source}</div>
        </div>
        <div class="modal-close">✕</div>
      </div>
      <div class="modal-content">
        <h2>${title}</h2>
        <div class="modal-image-container"></div>
        <div class="modal-date">${new Date().toLocaleDateString('pt-BR', { 
          day: '2-digit', 
          month: '2-digit', 
          year: 'numeric',
          hour: '2-digit',
          minute: '2-digit'
        })}</div>
        <div class="modal-text">
          <p>Lorem ipsum dolor sit amet, consectetur adipiscing elit. Suspendisse varius enim in eros elementum tristique. Duis cursus, mi quis viverra ornare, eros dolor interdum nulla, ut commodo diam libero vitae erat.</p>
          <p>Aenean faucibus nibh et justo cursus id rutrum lorem imperdiet. Nunc ut sem vitae risus tristique posuere. Vestibulum ante ipsum primis in faucibus orci luctus et ultrices posuere cubilia Curae; Fusce id purus.</p>
          <p>Ut aliquam purus sit amet luctus venenatis, lectus magna fringilla urna, porttitor rhoncus dolor purus non enim praesent elementum facilisis leo, vel fringilla est ullamcorper eget nulla facilisi.</p>
        </div>
      </div>
      <div class="modal-footer">
        <div class="share-buttons">
          <button class="share-button twitter">Twitter</button>
          <button class="share-button facebook">Facebook</button>
          <button class="share-button whatsapp">WhatsApp</button>
        </div>
        <button class="read-more-button">Ler notícia completa</button>
      </div>
    `;
    
    // Adiciona a imagem ao container
    modal.querySelector('.modal-image-container').appendChild(imageClone);
    
    // Adiciona o modal ao overlay
    overlay.appendChild(modal);
    
    // Adiciona o overlay ao body
    document.body.appendChild(overlay);
    
    // Bloqueia o scroll da página
    document.body.style.overflow = 'hidden';
    
    // Anima a entrada do modal
    setTimeout(() => {
      overlay.classList.add('active');
      modal.classList.add('active');
    }, 10);
    
    // Configura o botão de fechar
    modal.querySelector('.modal-close').addEventListener('click', () => {
      closeModal(overlay, modal);
    });
    
    // Fecha ao clicar fora do modal
    overlay.addEventListener('click', (e) => {
      if (e.target === overlay) {
        closeModal(overlay, modal);
      }
    });
    
    // Configura compartilhamento
    const shareButtons = modal.querySelectorAll('.share-button');
    shareButtons.forEach(button => {
      button.addEventListener('click', () => {
        const platform = button.classList[1]; // twitter, facebook, whatsapp
        shareNews(title, platform);
      });
    });
  }
  
  /**
   * Fecha o modal de notícia
   */
  function closeModal(overlay, modal) {
    modal.classList.remove('active');
    overlay.classList.remove('active');
    
    // Reativa o scroll após a animação
    setTimeout(() => {
      document.body.removeChild(overlay);
      document.body.style.overflow = '';
    }, 300);
  }
  
  /**
   * Simulação de compartilhamento de notícia
   */
  function shareNews(title, platform) {
    // Simulação de compartilhamento
    const message = `Compartilhando "${title}" via ${platform}`;
    console.log(message);
    showNotification(`Notícia compartilhada no ${platform}!`);
  }
  
  /**
   * Exibe uma notificação temporária
   */
  function showNotification(message) {
    // Remove notificações anteriores
    const existingNotification = document.querySelector('.notification');
    if (existingNotification) {
      document.body.removeChild(existingNotification);
    }
    
    // Cria nova notificação
    const notification = document.createElement('div');
    notification.className = 'notification';
    notification.textContent = message;
    
    // Adiciona ao body
    document.body.appendChild(notification);
    
    // Anima a entrada
    setTimeout(() => {
      notification.classList.add('active');
    }, 10);
    
    // Remove após alguns segundos
    setTimeout(() => {
      notification.classList.remove('active');
      setTimeout(() => {
        if (notification.parentNode) {
          document.body.removeChild(notification);
        }
      }, 300);
    }, 3000);
  }
  
  /**
   * Aplica animações nos elementos da página
   */
  function initializeAnimations() {
    // Animação para o título de destaque
    const destaqueTitulo = document.querySelector('.destaque-titulo');
    if (destaqueTitulo) {
      destaqueTitulo.classList.add('animate-title');
    }
    
    // Animação de entrada para os cards de notícias
    const newsCards = document.querySelectorAll('.noticia-card');
    newsCards.forEach((card, index) => {
      // Atrasa a animação de cada card para criar efeito cascata
      setTimeout(() => {
        card.classList.add('fade-in');
      }, 100 * index);
    });
    
    // Animação para a notícia em destaque
    const destaqueNoticia = document.querySelector('.destaque-noticia');
    if (destaqueNoticia) {
      destaqueNoticia.classList.add('slide-in');
    }
  }
  
  /**
   * Implementa rolagem infinita para carregar mais notícias
   */
  function initializeInfiniteScroll() {
    // Variável para controlar se há carregamento em andamento
    let isLoading = false;
    
    // Detector de scroll
    window.addEventListener('scroll', () => {
      // Verifica se o usuário chegou perto do final da página
      if (window.innerHeight + window.pageYOffset >= document.body.offsetHeight - 500) {
        // Carrega mais notícias se não estiver já carregando
        if (!isLoading) {
          loadMoreNews();
        }
      }
    });
    
    /**
     * Carrega mais notícias dinamicamente
     */
    function loadMoreNews() {
      isLoading = true;
      
      // Mostra indicador de carregamento
      const newsGrid = document.querySelector('.noticias-grid');
      const loadingIndicator = document.createElement('div');
      loadingIndicator.className = 'loading-indicator';
      loadingIndicator.innerHTML = '<div class="loading-spinner"></div><span>Carregando mais notícias...</span>';
      newsGrid.parentNode.insertBefore(loadingIndicator, newsGrid.nextSibling);
      
      // Simula carregamento (substitua por uma chamada AJAX real)
      setTimeout(() => {
        // Remove indicador de carregamento
        loadingIndicator.parentNode.removeChild(loadingIndicator);
        
        // Adiciona novas notícias
        addNewCards();
        
        // Marca como não mais carregando
        isLoading = false;
      }, 1500);
    }
    
    /**
     * Adiciona novos cards de notícias ao grid
     */
    function addNewCards() {
      const newsGrid = document.querySelector('.noticias-grid');
      const newsCardTemplate = document.querySelector('.noticia-card');
      
      // Dados simulados para novas notícias
      const newNewsData = [
        {
          fonte: 'G1 Economia',
          titulo: 'Preço do petróleo sobe 3% após anúncio da OPEP+ sobre cortes na produção',
          tempo: 'há 2 horas'
        },
        {
          fonte: 'Valor Econômico',
          titulo: 'Nova refinaria no Nordeste deve iniciar operações em 2026',
          tempo: 'há 3 horas'
        },
        {
          fonte: 'CNN Brasil',
          titulo: 'Exportações de petróleo batem recorde no primeiro trimestre de 2025',
          tempo: 'há 5 horas'
        },
        {
          fonte: 'Bloomberg',
          titulo: 'Petrobras anuncia investimento de R$ 30 bilhões em novas tecnologias verdes',
          tempo: 'há 8 horas'
        }
      ];
      
      // Cria e adiciona novos cards
      newNewsData.forEach(news => {
        const newCard = newsCardTemplate.cloneNode(true);
        
        // Atualiza conteúdo
        newCard.querySelector('.fonte-nome').textContent = news.fonte;
        newCard.querySelector('h4').textContent = news.titulo;
        newCard.querySelector('.tempo').textContent = news.tempo;
        
        // Atualiza imagem (aleatória para exemplo)
        const imageId = Math.floor(Math.random() * 1000);
        newCard.querySelector('img').src = `https://via.placeholder.com/120x80?text=News${imageId}`;
        
        // Reset classes para nova animação
        newCard.classList.remove('fade-in');
        
        // Adiciona ao grid
        newsGrid.appendChild(newCard);
        
        // Aplica animação após um pequeno delay
        setTimeout(() => {
          newCard.classList.add('fade-in');
        }, 100);
        
        // Adiciona eventos aos novos cards
        newCard.addEventListener('click', () => {
          const title = newCard.querySelector('h4').textContent;
          const source = newCard.querySelector('.fonte-nome').textContent;
          openNewsDetail(title, source, newCard);
        });
        
        // Adiciona botão de salvar
        if (!newCard.querySelector('.save-button')) {
          const saveButton = document.createElement('div');
          saveButton.className = 'save-button';
          saveButton.innerHTML = '🔖';
          saveButton.title = 'Salvar notícia';
          
          saveButton.addEventListener('click', (e) => {
            e.stopPropagation();
            saveButton.classList.toggle('saved');
            saveButton.innerHTML = saveButton.classList.contains('saved') ? '📌' : '🔖';
          });
          
          newCard.appendChild(saveButton);
        }
        
        // Atualiza tempo relativo
        updateRelativeTime(newCard.querySelector('.tempo'));
      });
    }
  }
  
  /**
   * Inicializa funcionalidade de filtro de notícias
   */
  function initializeNewsFilter() {
    // Cria os elementos de filtro
    const filterContainer = document.createElement('div');
    filterContainer.className = 'filter-container';
    
    // Título do filtro
    const filterTitle = document.createElement('div');
    filterTitle.className = 'filter-title';
    filterTitle.textContent = 'Filtrar por:';
    
    // Botões de filtro
    const filterButtons = [
      { label: 'Todas', active: true },
      { label: 'Petrobras' },
      { label: 'OPEP+' },
      { label: 'Mercado' },
      { label: 'Internacional' }
    ];
    
    const buttonsContainer = document.createElement('div');
    buttonsContainer.className = 'filter-buttons';
    
    filterButtons.forEach(filter => {
      const button = document.createElement('div');
      button.className = 'filter-button';
      if (filter.active) button.classList.add('active');
      button.textContent = filter.label;
      
      button.addEventListener('click', () => {
        // Remove classe ativa de todos os botões
        document.querySelectorAll('.filter-button').forEach(btn => {
          btn.classList.remove('active');
        });
        
        // Adiciona classe ativa ao botão clicado
        button.classList.add('active');
        
        // Filtra as notícias
        filterNews(filter.label);
      });
      
      buttonsContainer.appendChild(button);
    });
    
    // Monta a estrutura do filtro
    filterContainer.appendChild(filterTitle);
    filterContainer.appendChild(buttonsContainer);
    
    // Adiciona filtro após o destaque e antes do grid de notícias
    const destaque = document.querySelector('.destaque');
    const noticiasGrid = document.querySelector('.noticias-grid');
    
    if (destaque && noticiasGrid) {
      destaque.parentNode.insertBefore(filterContainer, noticiasGrid);
    }
  }
  
  /**
   * Filtra as notícias com base na categoria selecionada
   */
  function filterNews(category) {
    const newsCards = document.querySelectorAll('.noticia-card');
    
    // Simula filtragem de notícias por categoria
    // Em uma aplicação real, isso seria feito com dados reais
    newsCards.forEach(card => {
      const title = card.querySelector('h4').textContent.toLowerCase();
      
      if (category === 'Todas') {
        // Mostra todas as notícias
        showCardWithAnimation(card);
      } else if (title.includes(category.toLowerCase())) {
        // Mostra apenas as notícias que contêm a categoria
        showCardWithAnimation(card);
      } else {
        // Esconde as outras notícias
        hideCardWithAnimation(card);
      }
    });
    
    /**
     * Mostra um card com animação
     */
    function showCardWithAnimation(card) {
      card.style.display = 'block';
      setTimeout(() => {
        card.style.opacity = '1';
        card.style.transform = 'translateY(0)';
      }, 10);
    }
    
    /**
     * Esconde um card com animação
     */
    function hideCardWithAnimation(card) {
      card.style.opacity = '0';
      card.style.transform = 'translateY(20px)';
      setTimeout(() => {
        card.style.display = 'none';
      }, 300);
    }
  }
  
  /**
   * Inicializa funcionalidade de busca
   */
  function initializeSearchFunctionality() {
    // A busca é inicializada no cabeçalho, mas a função de busca é implementada aqui
    document.addEventListener('click', (e) => {
      // Verifica se o clique foi no botão de busca ou em algum elemento filho
      const searchButton = e.target.closest('.search-bar button');
      
      if (searchButton) {
        const searchInput = document.querySelector('.search-bar input');
        const searchTerm = searchInput.value.trim().toLowerCase();
        
        if (searchTerm.length > 2) {
          searchNews(searchTerm);
        } else {
          showNotification('Digite pelo menos 3 caracteres para buscar.');
        }
      }
    });
    
    // Pressionar Enter no campo de busca também ativa a busca
    document.addEventListener('keydown', (e) => {
      if (e.key === 'Enter') {
        const searchBar = document.querySelector('.search-bar.active');
        const searchInput = searchBar?.querySelector('input');
        
        if (searchInput && document.activeElement === searchInput) {
          const searchTerm = searchInput.value.trim().toLowerCase();
          
          if (searchTerm.length > 2) {
            searchNews(searchTerm);
          } else {
            showNotification('Digite pelo menos 3 caracteres para buscar.');
          }
        }
      }
    });
  }
  
  /**
   * Realiza a busca de notícias
   */
  function searchNews(term) {
    const newsCards = document.querySelectorAll('.noticia-card');
    let found = false;
    
    // Destaca o termo de busca nos resultados
    newsCards.forEach(card => {
      const title = card.querySelector('h4');
      const titleText = title.textContent.toLowerCase();
      
      if (titleText.includes(term)) {
        // Destaca o termo encontrado
        const highlightedText = title.textContent.replace(
          new RegExp(term, 'gi'),
          match => `<span class="highlight">${match}</span>`
        );
        
        title.innerHTML = highlightedText;
        
        // Mostra o card com animação especial
        card.style.display = 'block';
        card.classList.add('search-result');
        setTimeout(() => {
          card.style.opacity = '1';
          card.style.transform = 'translateY(0)';
        }, 10);
        
        found = true;
      } else {
        // Esconde os cards que não correspondem
        card.style.opacity = '0';
        card.style.transform = 'translateY(20px)';
        setTimeout(() => {
          card.style.display = 'none';
          card.classList.remove('search-result');
        }, 300);
      }
    });
    
    // Feedback para o usuário
    if (found) {
      showNotification(`Resultados encontrados para "${term}"`);
      
      // Botão para limpar a busca
      const clearButton = document.createElement('div');
      clearButton.className = 'clear-search';
      clearButton.textContent = 'Limpar busca';
      
      const noticiasGrid = document.querySelector('.noticias-grid');
      
      // Remove botão anterior se existir
      const existingButton = document.querySelector('.clear-search');
      if (existingButton) {
        existingButton.parentNode.removeChild(existingButton);
      }
      
      noticiasGrid.parentNode.insertBefore(clearButton, noticiasGrid);
      
      clearButton.addEventListener('click', () => {
        // Restaura todos os cards
        newsCards.forEach(card => {
          // Remove destaques
          const title = card.querySelector('h4');
          title.innerHTML = title.textContent;
          
          // Mostra todos os cards
          card.style.display = 'block';
          card.classList.remove('search-result');
          setTimeout(() => {
            card.style.opacity = '1';
            card.style.transform = 'translateY(0)';
          }, 10);
        });
        
        // Remove o botão de limpar
        clearButton.parentNode.removeChild(clearButton);
        
        // Limpa o campo de busca
        const searchInput = document.querySelector('.search-bar input');
        if (searchInput) searchInput.value = '';
      });
    } else {
      showNotification(`Nenhum resultado encontrado para "${term}"`);
    }
  }
  
  /**
   * Atualiza os tempos relativos (ex: "há X horas")
   */
  function updateRelativeTime(element) {
    if (!element) return;
    
    // Para demonstração, cria um tempo aleatório no passado
    const hours = parseInt(element.textContent.match(/\d+/)[0]);
    const minutes = Math.floor(Math.random() * 60);
    
    const now = new Date();
    const pastTime = new Date(now - (hours * 60 * 60 * 1000) - (minutes * 60 * 1000));
    
    updateTimeElement(element, pastTime);
    
    setInterval(() => {
      updateTimeElement(element, pastTime);
    }, 60000); 
  }
  
  function updateTimeElement(element, timestamp) {
    const now = new Date();
    const diff = Math.floor((now - timestamp) / 1000);
    
    let timeText;
    
    if (diff < 60) {
      timeText = 'agora mesmo';
    } else if (diff < 3600) {
      const minutes = Math.floor(diff / 60);
      timeText = `há ${minutes} ${minutes === 1 ? 'minuto' : 'minutos'}`;
    } else if (diff < 86400) {
      const hours = Math.floor(diff / 3600);
      timeText = `há ${hours} ${hours === 1 ? 'hora' : 'horas'}`;
    } else {
      const days = Math.floor(diff / 86400);
      timeText = `há ${days} ${days === 1 ? 'dia' : 'dias'}`;
    }
    
    element.textContent = timeText;
  }
  

  function setupNewsRefresh() {
    const refreshInterval = 5 * 60 * 1000; 
    
    setInterval(() => {
      const hasNewNews = Math.random() > 0.5;
      
      if (hasNewNews) {
        showNewNewsAlert();
      }
    }, refreshInterval);
  }
  
  function showNewNewsAlert() {
    const existingAlert = document.querySelector('.news-alert');
    if (existingAlert) {
      existingAlert.parentNode.removeChild(existingAlert);
    }
    
    const alertElement = document.createElement('div');
    alertElement.className = 'news-alert';
    alertElement.innerHTML = `
      <div class="alert-icon">🔔</div>
      <div class="alert-text">Novas notícias disponíveis</div>
      <div class="alert-refresh">Atualizar</div>
    `;
    
    document.body.appendChild(alertElement);
    
    setTimeout(() => {
      alertElement.classList.add('active');
    }, 10);
    
    alertElement.querySelector('.alert-refresh').addEventListener('click', () => {
      window.location.reload();
    });
    
    setTimeout(() => {
      alertElement.classList.remove('active');
      setTimeout(() => {
        if (alertElement.parentNode) {
          alertElement.parentNode.removeChild(alertElement);
        }
      }, 300);
    }, 30000);
  }